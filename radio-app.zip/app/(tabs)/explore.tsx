import { Typography } from "@/components/typography";
import { colors } from "@/constants/colors";
import { ScrollView, StyleSheet } from "react-native";

export default function ExploreScreen() {
  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={styles.contentContainer}>
      <Typography type="title">Explore</Typography>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.light.background,
  },

  contentContainer: {
    flex: 1,
    backgroundColor: colors.light.background,
  },
  titleContainer: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
});
